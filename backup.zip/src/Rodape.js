
const Rodape = () => {


    require('./Rodape.css');

    return(
        <footer className="Rodape">
            <ul>
                <li>Aluno 1</li>
                <li>Aluno 2</li>
                <li>Aluno 3</li>
                <li>Aluno 4</li>
            </ul>
        </footer>
    );


}

export default Rodape;